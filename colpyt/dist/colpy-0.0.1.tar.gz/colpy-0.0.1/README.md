# ColpyIMG <img src="colpy.png" width="30"/>

### Example:
```python
import colpy

exampleCode = colpy.ColpyConvert("example.png")
print(exampleCode.get())
exampleCode.export("example") #filename here is optional and defaults to "pycode"
```